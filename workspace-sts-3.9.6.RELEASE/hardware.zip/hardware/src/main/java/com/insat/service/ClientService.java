package com.insat.service;

import com.insat.model.Client;

public interface ClientService {	
	
	Client findByEmail(String email) ;

}
